"""
Constantes que são compartilhadas pelas funções usadas no trabalho
"""
ESTADO_FINAL = "12345678_"
POSICAO_VAZIA = "_"
NUMERO_COLUNAS = 3
NUMERO_LINHAS = 3
TAMANHO_ESTADO = 9
MANHATTAN = "manhattan"
HAMMING = "hamming"
