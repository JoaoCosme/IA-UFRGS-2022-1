# IA 2022/1 - GRUPO 5

|Nome|Cartao|Turma|
|---|---|----|
|Alice Santin Varella| 00259915 | B
|Joao Pedro Cosme da Silva|00314792 |A
|Eduardo André Leite | 00287684| A